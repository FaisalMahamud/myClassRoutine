package com.example.faisal.myclassroutine;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Routine extends AppCompatActivity {

    EditText E1,E2,E3,E4;
    Button B1;
    sqlite my;

    TextView T1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_routine);
        E1 = (EditText)findViewById(R.id.editText);
        E2 = (EditText)findViewById(R.id.editText2);
        E3 = (EditText)findViewById(R.id.editText3);
        E4 = (EditText)findViewById(R.id.editText4);
        B1 =(Button)findViewById(R.id.button);
        T1 = (TextView)findViewById(R.id.textView);


        my = new sqlite(this);

        B1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean checkers = my.addtotable(E1.getText().toString(),E2.getText().toString(),E3.getText().toString(),E4.getText().toString());
                if(checkers == true){
                    Toast.makeText(Routine.this,"Successfully Inserted",Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(Routine.this,"This id already Inserted,please change your ID ",Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    public void viewdata(View view){
        Cursor result = my.display();
        if(result.getCount()==0){
            Toast.makeText(this,"No data found",Toast.LENGTH_LONG).show();
            return;
        }
        result.moveToFirst();
        StringBuffer buffer = new StringBuffer();
        do{
            buffer.append("ID:"+ result.getString(0)+"\n");
            buffer.append("Course Name:"+ result.getString(1)+"\n");
            buffer.append("Date :"+ result.getString(2)+"\n");
            buffer.append("Time:"+ result.getString(3)+"\n\n");

        }while (result.moveToNext());
        Display(buffer.toString());
    }

    public void Display(String data){

        T1.setText(data);
    }

    public void updatedata(View view){
        boolean checker = my.updatedata(E1.getText().toString(),E2.getText().toString(),E3.getText().toString(),E4.getText().toString());
        if(checker == true){
            Toast.makeText(Routine.this,"Data Updated Successfully",Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(Routine.this,"Error Data Not Updated",Toast.LENGTH_SHORT).show();
        }
    }

    public void deletedata(View view){
        int deletechecker = my.deletedata(E1.getText().toString());
        if(deletechecker>0){
            Toast.makeText(Routine.this,"Data Deleted Successfully",Toast.LENGTH_LONG).show();

        }
        else{
            Toast.makeText(Routine.this,"Data not Deleted",Toast.LENGTH_SHORT).show();
        }
    }
    }

